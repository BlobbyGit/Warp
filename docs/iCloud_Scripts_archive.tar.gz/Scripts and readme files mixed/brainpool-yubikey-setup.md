# YubiKey Brainpool Keys Setup

## Issue with Current Configuration

Your YubiKey's OpenPGP application is currently having issues with GPG detection on macOS. This is a known issue with certain GPG configurations on macOS.

## Solutions for Brainpool Keys

### Option 1: Fix GPG Configuration (Recommended)

The OpenPGP application on your YubiKey supports Brainpool curves (brainpoolP256r1, brainpoolP384r1, brainpoolP512r1), but GPG needs proper configuration.

1. **Try with gpg-suite instead of homebrew GPG:**
   ```bash
   # Install GPG Suite which has better macOS integration
   brew install --cask gpg-suite
   ```

2. **Alternative: Use a different machine or VM**
   - Use a Linux machine or VM where GPG/YubiKey integration works more reliably
   - Ubuntu, Debian, or Fedora typically have better support

### Option 2: Generate Brainpool Keys via Manual GPG Commands

Once GPG can detect the card, use these commands:

```bash
# Generate brainpoolP256r1 key
gpg --expert --full-gen-key
# Select option 1 (RSA and RSA) then change to ECC
# Select curve brainpoolP256r1
# Follow prompts to generate on-card

# Generate brainpoolP384r1 key  
gpg --expert --full-gen-key
# Select ECC and ECC
# Select curve brainpoolP384r1
# Follow prompts to generate on-card
```

### Option 3: Use PIV with Standard NIST Curves

Your YubiKey already has working ECCP256 and ECCP384 keys in the PIV application:
- These provide similar security to Brainpool curves
- PKCS#11 module already configured and working
- Compatible with most applications

## Current Working Configuration

✅ **PKCS#11 Module**: `/opt/homebrew/lib/libykcs11.dylib`
✅ **PIV Keys Available**:
- Slot 9A: Authentication (ECCP256)
- Slot 9C: Signature (RSA2048)
- Slot 9D: Key Management (ECCP256)  
- Slot 9E: Card Authentication (ECCP256)

## Next Steps

1. Follow the Tor Browser configuration steps from the setup script
2. If you specifically need Brainpool curves, try Option 1 above
3. For most use cases, the existing PIV ECDSA keys provide equivalent security

## OpenPGP Application Reset Info

- PIN: 123456
- Admin PIN: 12345678
- The OpenPGP application has been reset and is ready for key generation once GPG detection is fixed