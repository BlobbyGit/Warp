# Blue Folder - Script Collection

This folder contains portable scripts that can run from the SD drive without issues.

## Scripts Included

### ✅ Fully Portable Scripts
These scripts have no hard-coded path dependencies and will work from anywhere:

1. **`set_user_agent.sh`**
   - Sets Chrome user agent for Safari (helps with DRM compatibility)
   - Usage: `./set_user_agent.sh`
   - To reset: `defaults delete com.apple.Safari CustomUserAgent`

2. **`verify_certificates.sh`**
   - Tests certificate verification and DRM functionality
   - Usage: `./verify_certificates.sh`
   - Helps diagnose Safari playback error 20001

3. **`hello.py`**
   - Simple Python hello world program
   - Usage: `python3 hello.py` or `./hello.py`

### 📝 Modified for Portability

4. **`system_check_portable.sh`**
   - Portable version of the main system security check
   - Calculates security score based on FileVault, Firewall, YubiKey, etc.
   - Usage: `./system_check_portable.sh`
   - Still logs to your home directory but can run from SD card
   - Uses absolute paths to avoid dependency issues

## Scripts NOT Included (Path Dependencies)

The following scripts were **not copied** because they have hard-coded path dependencies that would break if moved:

- `system_check_with_backup.sh` - Original version with full backup functionality
- `smartsync-control.sh` - Expects specific LaunchAgent files and home directory structure

## Usage Notes

- All scripts are executable and ready to run
- The SD drive path is: `/Volumes/SD/blue/`
- Scripts will work even when SD drive is disconnected (if copied elsewhere)
- For security scripts, they still reference your home directory for logging

## Quick Commands

From terminal, you can run any script with:
```bash
/Volumes/SD/blue/script_name.sh
```

Or navigate to the folder first:
```bash
cd /Volumes/SD/blue
./script_name.sh
```

---
*Scripts organized on $(date '+%Y-%m-%d')*