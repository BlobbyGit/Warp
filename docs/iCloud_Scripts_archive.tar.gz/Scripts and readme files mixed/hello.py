#!/usr/bin/env python3
"""
Hello World Application

A simple hello world program.
"""

def main():
    """Main function that prints hello message."""
    print("Hello, World!")
    print("Welcome to your new project!")

if __name__ == "__main__":
    main()