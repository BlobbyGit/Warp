#!/bin/bash

# Enhanced System Security Status Report (Portable Version)
# This version can run from anywhere including SD card
# Based on original system_check_with_backup.sh

# Set up logging using absolute paths
LOG_DIR="$HOME/Library/Logs"
SECURITY_LOG="$LOG_DIR/security_scores.csv"
BACKUP_LOG="$LOG_DIR/timemachine_backups.log"
REPORT_FILE="$HOME/Library/Mobile Documents/com~apple~CloudDocs/🔴_SECURITY_BACKUP copy/SYSTEM_STATUS_$(date +%Y%m%d).txt"

# Ensure log directories exist
mkdir -p "$LOG_DIR"
mkdir -p "$(dirname "$REPORT_FILE")"

# Email settings (using rule: jaytiltins@icloud.com)
EMAIL_TO="jaytiltins@icloud.com"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to log messages
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$BACKUP_LOG"
}

# Function to check Time Machine status
check_time_machine() {
    local tm_enabled=0
    local tm_destination=""
    local last_backup=""
    local backup_size=""
    local tm_status=""
    
    # Check if Time Machine is enabled
    if tmutil status &>/dev/null; then
        tm_enabled=1
        
        # Get destination info
        tm_destination=$(tmutil destinationinfo 2>/dev/null | grep "Name" | cut -d: -f2 | xargs)
        
        # Get last backup date
        last_backup=$(tmutil latestbackup 2>/dev/null)
        if [[ -n "$last_backup" ]]; then
            last_backup_date=$(stat -f "%Sm" -t "%Y-%m-%d %H:%M:%S" "$last_backup" 2>/dev/null)
        else
            last_backup_date="Never"
        fi
        
        # Get backup size
        backup_size=$(tmutil calculatedrift 2>/dev/null | grep "bytes" | head -1 | awk '{print $1}' 2>/dev/null)
        
        # Check if backup is running
        tm_running=$(tmutil status | grep "Running = 1" &>/dev/null && echo "Yes" || echo "No")
        
        tm_status="ENABLED ✓"
    else
        tm_status="DISABLED ❌"
        last_backup_date="N/A"
        tm_running="No"
    fi
    
    echo "$tm_enabled|$tm_destination|$last_backup_date|$backup_size|$tm_running|$tm_status"
}

# Function to calculate security score
calculate_security_score() {
    local score=0
    local max_score=10
    
    # FileVault (1 point)
    if fdesetup status | grep -q "FileVault is On"; then
        score=$((score + 1))
    fi
    
    # Firewall (1 point)
    if /usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate | grep -q "Firewall is enabled"; then
        score=$((score + 1))
    fi
    
    # Stealth mode (1 point)
    if /usr/libexec/ApplicationFirewall/socketfilterfw --getstealthmode | grep -q "Stealth mode enabled"; then
        score=$((score + 1))
    fi
    
    # DNS check (1 point) - Check for Quad9
    if scutil --dns | grep -q "9.9.9.9"; then
        score=$((score + 1))
    fi
    
    # YubiKey (1 point)
    if system_profiler SPUSBDataType | grep -q "YubiKey"; then
        score=$((score + 1))
    fi
    
    # System updates (1 point)
    if softwareupdate -l 2>&1 | grep -q "No new software available"; then
        score=$((score + 1))
    fi
    
    # SIP (1 point)
    if csrutil status | grep -q "enabled"; then
        score=$((score + 1))
    fi
    
    # Time Machine (1 point)
    tm_info=$(check_time_machine)
    tm_enabled=$(echo "$tm_info" | cut -d'|' -f1)
    if [[ "$tm_enabled" == "1" ]]; then
        score=$((score + 1))
    fi
    
    # Security processes (1 point) - Check for Bitdefender/Malwarebytes
    if pgrep -f "bitdefender\|malwarebytes" > /dev/null; then
        score=$((score + 1))
    fi
    
    # Bitwarden (1 point)
    if ls /Applications/ | grep -i "bitwarden" > /dev/null; then
        score=$((score + 1))
    fi
    
    echo "$score/$max_score"
}

# Function to send email report
send_email_report() {
    if command -v mail >/dev/null 2>&1; then
        mail -s "System Security Report - $(date '+%Y-%m-%d')" "$EMAIL_TO" < "$REPORT_FILE"
        log_message "Email report sent to $EMAIL_TO"
    else
        log_message "WARNING: mail command not available, report not emailed"
    fi
}

# Main execution - simplified for portable use
echo -e "${GREEN}Portable System Security Check${NC}"
echo "======================================"

# Calculate and display security score
security_score=$(calculate_security_score)
echo -e "\n${GREEN}Current Security Score: $security_score${NC}"

# Check Time Machine status
tm_info=$(check_time_machine)
tm_enabled=$(echo "$tm_info" | cut -d'|' -f1)
tm_last_backup=$(echo "$tm_info" | cut -d'|' -f3)

if [[ "$tm_enabled" == "1" ]]; then
    echo -e "${GREEN}✅ Time Machine is enabled${NC}"
    echo -e "Last backup: $tm_last_backup"
else
    echo -e "${RED}❌ Time Machine is not configured${NC}"
    echo -e "${YELLOW}Recommendation: Set up Time Machine backup for full security${NC}"
fi

# Show key security status
echo -e "\n${BLUE}Security Status Summary:${NC}"
echo "FileVault: $(fdesetup status | grep -q "FileVault is On" && echo "✅ ENABLED" || echo "❌ DISABLED")"
echo "Firewall: $(/usr/libexec/ApplicationFirewall/socketfilterfw --getglobalstate | grep -q "Firewall is enabled" && echo "✅ ENABLED" || echo "❌ DISABLED")"
echo "YubiKey: $(system_profiler SPUSBDataType | grep -q "YubiKey" && echo "✅ Detected" || echo "❌ Not Found")"
echo "DNS: $(scutil --dns | grep -q "9.9.9.9" && echo "✅ Quad9" || echo "❌ Default")"

# Log security score
echo "$(date '+%Y-%m-%d %H:%M:%S'),$security_score" >> "$SECURITY_LOG"

echo -e "\n${GREEN}Portable security check completed!${NC}"
echo "This script can run from anywhere including SD card."

exit 0