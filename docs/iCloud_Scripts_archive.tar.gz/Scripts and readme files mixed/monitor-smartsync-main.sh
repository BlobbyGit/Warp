#!/bin/bash

# Consolidated Smart Sync Monitor
# Watches the main folder and automatically distributes files to appropriate subfolders

MAIN_FOLDER="$HOME/Desktop/SmartSync-Main"
ICLOUD_BASE="$HOME/Library/Mobile Documents/com~apple~CloudDocs"

# Create logs directory
mkdir -p ~/Library/Logs/SmartSync

echo "🔍 Smart Sync monitoring $MAIN_FOLDER..."
echo "📋 Log files: ~/Library/Logs/SmartSync/"

fswatch -o "$MAIN_FOLDER" | while read f; do
    for file in "$MAIN_FOLDER"/*; do
        # Skip if it's a directory (our subfolders) or doesn't exist
        if [[ -d "$file" ]] || [[ ! -e "$file" ]]; then
            continue
        fi
        
        filename=$(basename "$file")
        extension="${filename##*.}"
        extension=$(echo "$extension" | tr '[:upper:]' '[:lower:]')
        
        echo "$(date): Processing $filename" >> ~/Library/Logs/SmartSync/activity.log
        
        case "$extension" in
            jpg|jpeg|png|gif|bmp|tiff|heic|raw|cr2|nef|webp|svg)
                mv "$file" "$ICLOUD_BASE/Photos-ToSync/"
                osascript -e 'display notification "📸 Photo moved to iCloud Photos folder" with title "Smart Sync"'
                echo "$(date): Moved $filename to Photos-ToSync" >> ~/Library/Logs/SmartSync/activity.log
                ;;
            pdf|doc|docx|txt|rtf|pages|xlsx|pptx|keynote|numbers|csv|md)
                mv "$file" "$ICLOUD_BASE/Documents-ToSync/"
                osascript -e 'display notification "📄 Document moved to iCloud Documents folder" with title "Smart Sync"'
                echo "$(date): Moved $filename to Documents-ToSync" >> ~/Library/Logs/SmartSync/activity.log
                ;;
            *)
                if [[ "$filename" == *"Screenshot"* ]] || [[ "$filename" == *"Screen Shot"* ]] || [[ "$filename" == *"CleanShot"* ]]; then
                    mv "$file" "$ICLOUD_BASE/Screenshots/"
                    osascript -e 'display notification "📱 Screenshot moved to iCloud Screenshots folder" with title "Smart Sync"'
                    echo "$(date): Moved $filename to Screenshots" >> ~/Library/Logs/SmartSync/activity.log
                else
                    mv "$file" "$ICLOUD_BASE/SmartSync/"
                    osascript -e 'display notification "📁 File moved to iCloud SmartSync folder" with title "Smart Sync"'
                    echo "$(date): Moved $filename to SmartSync" >> ~/Library/Logs/SmartSync/activity.log
                fi
                ;;
        esac
    done
done
