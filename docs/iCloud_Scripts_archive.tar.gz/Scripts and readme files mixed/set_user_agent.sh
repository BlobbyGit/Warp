#!/bin/bash

# Set Chrome user agent for Safari (sometimes helps with DRM)
defaults write com.apple.Safari CustomUserAgent '"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"'

echo "User agent set to Chrome for compatibility"
echo "To reset: defaults delete com.apple.Safari CustomUserAgent"



