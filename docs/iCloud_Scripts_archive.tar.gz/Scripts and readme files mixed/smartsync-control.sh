#!/bin/bash

# Smart Sync Control Script

case "$1" in
    start)
        echo "🚀 Starting Smart Sync monitoring..."
        launchctl load ~/Library/LaunchAgents/com.smartsync.monitor.plist
        echo "✅ Smart Sync is now running automatically!"
        echo "📁 Drop files in ~/Desktop/SmartSync-Main and they'll be organized automatically"
        ;;
    stop)
        echo "🛑 Stopping Smart Sync monitoring..."
        launchctl unload ~/Library/LaunchAgents/com.smartsync.monitor.plist
        echo "✅ Smart Sync stopped"
        ;;
    status)
        if launchctl list | grep -q com.smartsync.monitor; then
            echo "✅ Smart Sync is running"
        else
            echo "❌ Smart Sync is not running"
        fi
        ;;
    test)
        echo "🧪 Testing Smart Sync with sample files..."
        echo "Sample photo" > ~/Desktop/SmartSync-Main/test-image.jpg
        echo "Sample document" > ~/Desktop/SmartSync-Main/test-document.pdf
        echo "Sample text" > ~/Desktop/SmartSync-Main/sample.txt
        echo "Screenshot test" > ~/Desktop/SmartSync-Main/Screenshot-test.png
        sleep 2
        echo "📊 Results:"
        echo "Photos folder: $(ls ~/Library/Mobile\ Documents/com~apple~CloudDocs/Photos-ToSync/ | wc -l) files"
        echo "Documents folder: $(ls ~/Library/Mobile\ Documents/com~apple~CloudDocs/Documents-ToSync/ | wc -l) files"
        echo "Screenshots folder: $(ls ~/Library/Mobile\ Documents/com~apple~CloudDocs/Screenshots/ | wc -l) files"
        echo "General folder: $(ls ~/Library/Mobile\ Documents/com~apple~CloudDocs/SmartSync/ | wc -l) files"
        ;;
    *)
        echo "🔧 Smart Sync Control"
        echo "Usage: $0 {start|stop|status|test}"
        echo ""
        echo "Commands:"
        echo "  start  - Start automatic file monitoring"
        echo "  stop   - Stop automatic file monitoring"
        echo "  status - Check if monitoring is running"
        echo "  test   - Test the system with sample files"
        echo ""
        echo "📂 Your Smart Sync System:"
        echo "   • ~/Desktop/SmartSync-Main (main drop folder)"
        echo "     ├── Photos-ToSync (images)"
        echo "     ├── Documents-ToSync (documents)"
        echo "     ├── Screenshots (screenshots)"
        echo "     └── SmartSync (general files)"
        echo "   • Logs: ~/Library/Logs/SmartSync/"
        ;;
esac
