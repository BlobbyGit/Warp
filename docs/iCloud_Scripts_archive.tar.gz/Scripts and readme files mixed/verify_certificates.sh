#!/bin/bash

echo "Certificate Verification Test"
echo "============================="
echo ""

# Check keychain is unlocked
echo "1. Keychain status:"
security show-keychain-info ~/Library/Keychains/login.keychain-db 2>&1 | grep -q "locked" && echo "   ⚠️  LOCKED" || echo "   ✓ Unlocked"

# Check Safari can access certificates
echo ""
echo "2. Safari certificate test:"
osascript -e 'tell application "Safari" to open location "https://badssl.com/"' 2>/dev/null
echo "   If Safari shows certificate warnings, certificates are working"

# Check DRM servers
echo ""
echo "3. Testing DRM endpoints:"
curl -I https://fairplay.apple.com 2>/dev/null | head -1
curl -I https://widevine.google.com 2>/dev/null | head -1

echo ""
echo "4. Quick playback test:"
echo "   Opening test video..."
open -a Safari "https://www.w3schools.com/html/mov_bbb.mp4"
echo "   This should play without error 20001"

echo ""
echo "If error 20001 still appears:"
echo "1. Open Keychain Access.app"
echo "2. Click 'login' keychain"
echo "3. Go to File > Lock/Unlock keychain"
echo "4. Enter your password to unlock"
echo "5. Try playing video again"
