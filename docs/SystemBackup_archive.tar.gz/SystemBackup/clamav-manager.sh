#!/bin/zsh
# ClamAV Manager - Quick access to scanning and monitoring

case "$1" in
    scan-now)
        echo "🔍 Starting quick scan of critical directories..."
        clamscan --recursive --infected \
            --exclude-dir=Library/Caches \
            --exclude-dir=.Trash \
            --max-filesize=100M \
            ~/Downloads ~/Documents ~/Desktop
        ;;
    
    scan-full)
        echo "🔍 Starting full home directory scan (this may take a while)..."
        clamscan --recursive --infected \
            --exclude-dir=Library/Caches \
            --exclude-dir=.Trash \
            --max-filesize=150M \
            ~/
        ;;
    
    update)
        echo "📥 Updating virus definitions..."
        freshclam
        ;;
    
    logs)
        echo "📋 Recent scan logs:"
        echo "\n=== DAILY SCAN LOG ==="
        tail -20 ~/clamav_daily_scan.log 2>/dev/null || echo "No daily scan log yet"
        echo "\n=== WEEKLY SCAN LOG ==="
        tail -20 ~/clamav_weekly_scan.log 2>/dev/null || echo "No weekly scan log yet"
        ;;
    
    status)
        echo "🛡️  ClamAV Status:"
        echo "\nServices:"
        launchctl list | grep clamav
        echo "\nVirus definitions:"
        clamscan --version
        echo "\nLast scan logs modified:"
        ls -lh ~/clamav_*scan.log 2>/dev/null || echo "No scan logs found yet"
        ;;
    
    *)
        echo "ClamAV Manager"
        echo "Usage: $0 {scan-now|scan-full|update|logs|status}"
        echo ""
        echo "Commands:"
        echo "  scan-now   - Quick scan of Downloads, Documents, Desktop"
        echo "  scan-full  - Full scan of home directory"
        echo "  update     - Update virus definitions manually"
        echo "  logs       - View recent scan logs"
        echo "  status     - Check ClamAV service status"
        ;;
esac
