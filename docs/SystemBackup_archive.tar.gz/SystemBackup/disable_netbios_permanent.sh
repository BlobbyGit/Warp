#!/bin/bash
# Permanently disable NetBIOS on macOS
# This disables both the netbiosd and smbd services

echo "🔒 Disabling NetBIOS permanently..."

# Disable NetBIOS daemon
sudo launchctl bootout system/com.apple.netbiosd 2>/dev/null
sudo launchctl disable system/com.apple.netbiosd 2>/dev/null

# Clear NetBIOS name
sudo defaults write /Library/Preferences/SystemConfiguration/com.apple.smb.server NetBIOSName -string ""

# Disable SMB daemon
sudo launchctl unload -w /System/Library/LaunchDaemons/com.apple.smbd.plist 2>/dev/null

# Verify
echo ""
echo "Verification:"
NETBIOS_STATUS=$(sudo launchctl print system/com.apple.netbiosd 2>&1)
if echo "$NETBIOS_STATUS" | grep -q "Could not find service"; then
    echo "  NetBIOS: ✅ DISABLED"
else
    echo "  NetBIOS: ❌ STILL RUNNING"
fi

SMB_CHECK=$(ps aux | grep -E "smbd|netbiosd" | grep -v grep)
if [ -z "$SMB_CHECK" ]; then
    echo "  SMB processes: ✅ NONE RUNNING"
else
    echo "  SMB processes: ❌ STILL RUNNING"
    echo "  $SMB_CHECK"
fi

NETBIOS_NAME=$(defaults read /Library/Preferences/SystemConfiguration/com.apple.smb.server NetBIOSName 2>/dev/null)
if [ -z "$NETBIOS_NAME" ]; then
    echo "  NetBIOS name: ✅ CLEARED"
else
    echo "  NetBIOS name: ⚠️  Still set to: $NETBIOS_NAME"
fi

echo ""
echo "Done. NetBIOS should now be permanently disabled."
