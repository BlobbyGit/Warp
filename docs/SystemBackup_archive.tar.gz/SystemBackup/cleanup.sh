#!/bin/bash

##############################################
# macOS Cleanup Script
# Safely removes junk files to free up space
##############################################

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Counters
TOTAL_FREED=0
ORIGINAL_SPACE=0
FINAL_SPACE=0

# Function to format bytes to human-readable format
format_bytes() {
    local bytes=$1
    if (( bytes < 1024 )); then
        echo "${bytes}B"
    elif (( bytes < 1048576 )); then
        echo "$(( bytes / 1024 ))KB"
    elif (( bytes < 1073741824 )); then
        echo "$(( bytes / 1048576 ))MB"
    else
        echo "$(( bytes / 1073741824 ))GB"
    fi
}

# Function to get directory size
get_dir_size() {
    du -sk "$1" 2>/dev/null | awk '{print $1 * 1024}'
}

echo -e "${YELLOW}=== macOS Cleanup Tool ===${NC}"
echo ""
echo "Getting initial disk space..."
ORIGINAL_SPACE=$(df / | awk 'NR==2 {print $4 * 1024}')

# 1. Empty Trash
echo -e "${YELLOW}1. Emptying Trash...${NC}"
rm -rf ~/.Trash/* 2>/dev/null && echo -e "${GREEN}✓ Trash emptied${NC}" || echo -e "${RED}✗ Could not empty trash${NC}"

# 2. Clear System Cache
echo -e "${YELLOW}2. Clearing system cache...${NC}"
rm -rf ~/Library/Caches/* 2>/dev/null && echo -e "${GREEN}✓ User cache cleared${NC}" || echo "Cache cleanup partial"

# 3. Clear Browser Cache
echo -e "${YELLOW}3. Clearing browser cache...${NC}"
rm -rf ~/Library/Safari/History.db* 2>/dev/null
rm -rf ~/Library/Application\ Support/Google/Chrome/Default/Cache/* 2>/dev/null
rm -rf ~/Library/Application\ Support/Firefox/Profiles/*/cache* 2>/dev/null
echo -e "${GREEN}✓ Browser cache cleared${NC}"

# 4. Remove old logs
echo -e "${YELLOW}4. Cleaning old logs...${NC}"
rm -rf ~/Library/Logs/* 2>/dev/null
find /var/log -name "*.log" -type f -mtime +30 -delete 2>/dev/null
echo -e "${GREEN}✓ Old logs removed${NC}"

# 5. Clear temporary files
echo -e "${YELLOW}5. Clearing temporary files...${NC}"
rm -rf /tmp/* 2>/dev/null
rm -rf /var/tmp/* 2>/dev/null
rm -rf /var/folders/*/T/* 2>/dev/null
echo -e "${GREEN}✓ Temporary files cleared${NC}"

# 6. Remove old Xcode files
echo -e "${YELLOW}6. Cleaning Xcode (if installed)...${NC}"
rm -rf ~/Library/Developer/Xcode/DerivedData/* 2>/dev/null && echo -e "${GREEN}✓ Xcode derived data cleared${NC}" || echo "Xcode cleanup skipped"
rm -rf ~/Library/Developer/Xcode/Archives/* 2>/dev/null

# 7. Clear old Application Support files
echo -e "${YELLOW}7. Clearing old application support files...${NC}"
rm -rf ~/Library/Application\ Support/CrashReporter/* 2>/dev/null
echo -e "${GREEN}✓ Crash reports cleared${NC}"

# 8. Remove broken app cache
echo -e "${YELLOW}8. Clearing app cache...${NC}"
rm -rf ~/Library/Application\ Support/*/Cache/* 2>/dev/null
echo -e "${GREEN}✓ App cache cleared${NC}"

# 9. Empty Downloads (older than 30 days)
echo -e "${YELLOW}9. Removing old downloads (>30 days)...${NC}"
find ~/Downloads -type f -mtime +30 -delete 2>/dev/null
echo -e "${GREEN}✓ Old downloads removed${NC}"

# 10. Clear Spotlight index files
echo -e "${YELLOW}10. Clearing Spotlight index...${NC}"
mdutil -i off / 2>/dev/null
mdutil -i on / 2>/dev/null
echo -e "${GREEN}✓ Spotlight cache cleared${NC}"

# 11. Remove language files (keep English only)
echo -e "${YELLOW}11. Removing unused language files...${NC}"
find /Applications -name "*.lproj" ! -name "en.lproj" -delete 2>/dev/null
echo -e "${GREEN}✓ Language files cleaned${NC}"

# 12. Purge memory cache
echo -e "${YELLOW}12. Purging memory cache...${NC}"
purge 2>/dev/null && echo -e "${GREEN}✓ Memory cache purged${NC}" || echo "Memory purge requires admin"

echo ""
echo "Getting final disk space..."
FINAL_SPACE=$(df / | awk 'NR==2 {print $4 * 1024}')

TOTAL_FREED=$((FINAL_SPACE - ORIGINAL_SPACE))

echo ""
echo -e "${GREEN}=== Cleanup Complete ===${NC}"
echo -e "Space freed: ${GREEN}$(format_bytes $TOTAL_FREED)${NC}"
echo ""
echo "Note: Some operations require admin privileges."
echo "For maximum cleanup, run with: sudo bash cleanup.sh"
