#!/bin/zsh
# compress_pdf.sh — Compress a PDF using qpdf + ghostscript for maximum size reduction
# Usage:   compress_pdf.sh <input.pdf> [target_MB]
# Example: compress_pdf.sh ~/Desktop/doc.pdf 5

INPUT="$1"
TARGET_MB="${2:-5}"
TARGET_BYTES=$(( TARGET_MB * 1024 * 1024 ))

if [[ -z "$INPUT" ]]; then
  echo "Usage: compress_pdf.sh <input.pdf> [target_MB]"
  echo "Example: compress_pdf.sh ~/Desktop/doc.pdf 5"
  exit 1
fi

if [[ ! -f "$INPUT" ]]; then
  echo "Error: File not found: $INPUT"
  exit 1
fi

BASENAME="${INPUT%.pdf}"
OUTPUT="${BASENAME}_compressed.pdf"
TMP="${TMPDIR:-/tmp}/compress_pdf_tmp_$$.pdf"
ORIGINAL_SIZE=$(stat -f%z "$INPUT")
ORIGINAL_MB=$(echo "scale=1; $ORIGINAL_SIZE / 1048576" | bc)

echo "📄 Original: ${ORIGINAL_MB}MB → Target: under ${TARGET_MB}MB"

# Step 1: qpdf pass — compress text/font streams losslessly
echo "  Step 1/2: qpdf stream compression..."
qpdf --compress-streams=y --object-streams=generate --recompress-flate \
  "$INPUT" "$TMP" 2>/dev/null || cp "$INPUT" "$TMP"

# Step 2: ghostscript pass — compress images
for QUALITY in /ebook /screen; do
  echo "  Step 2/2: Ghostscript image compression ($QUALITY)..."
  gs -sDEVICE=pdfwrite -dCompatibilityLevel=1.4 -dPDFSETTINGS="$QUALITY" \
     -dNOPAUSE -dQUIET -dBATCH \
     -sOutputFile="$OUTPUT" "$TMP"

  FINAL_SIZE=$(stat -f%z "$OUTPUT")
  FINAL_MB=$(echo "scale=1; $FINAL_SIZE / 1048576" | bc)

  if (( FINAL_SIZE <= TARGET_BYTES )); then
    rm -f "$TMP"
    echo "✅ Done! ${ORIGINAL_MB}MB → ${FINAL_MB}MB"
    echo "   Saved to: $OUTPUT"
    exit 0
  fi

  echo "  Still ${FINAL_MB}MB, trying next quality..."
done

rm -f "$TMP"
FINAL_MB=$(echo "scale=1; $(stat -f%z "$OUTPUT") / 1048576" | bc)
echo "⚠️  Best result: ${ORIGINAL_MB}MB → ${FINAL_MB}MB (target was ${TARGET_MB}MB)"
echo "   Saved to: $OUTPUT"
