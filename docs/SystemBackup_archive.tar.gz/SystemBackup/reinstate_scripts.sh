#!/bin/bash
# Reinstate All Scripts
# Copies scripts from ~/Scripts From warp/ to expected locations,
# sets permissions, and reloads LaunchAgents.

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

SRC="$HOME/Scripts From warp"

echo "🔧 Reinstating all scripts..."
echo "=============================="
echo ""

# Check source directory exists
if [ ! -d "$SRC" ]; then
    echo -e "${RED}❌ Source directory not found: $SRC${NC}"
    exit 1
fi

# --- Copy to home directory ---
echo "📂 Copying scripts to home directory..."
SCRIPTS=(
    "battery_monitor.sh"
    "bitwarden_backup.sh"
    "clamav-manager.sh"
    "system_check_backup.sh"
    "bitwarden-audit.sh"
    "breach-monitor.sh"
)

for script in "${SCRIPTS[@]}"; do
    if [ -f "$SRC/$script" ]; then
        cp "$SRC/$script" "$HOME/$script"
        echo -e "  ${GREEN}✓${NC} $script"
    else
        echo -e "  ${YELLOW}⚠️  Not found in source: $script${NC}"
    fi
done

# --- Copy to .local/bin ---
echo ""
echo "📂 Copying scripts to ~/.local/bin..."
mkdir -p "$HOME/.local/bin"

LOCAL_SCRIPTS=(
    "system_check_backup.sh"
    "clamav-manager.sh"
)

for script in "${LOCAL_SCRIPTS[@]}"; do
    if [ -f "$SRC/$script" ]; then
        cp "$SRC/$script" "$HOME/.local/bin/$script"
        echo -e "  ${GREEN}✓${NC} $script"
    else
        echo -e "  ${YELLOW}⚠️  Not found in source: $script${NC}"
    fi
done

# --- Set permissions ---
echo ""
echo "🔑 Setting executable permissions..."
chmod +x "$HOME"/*.sh "$HOME/.local/bin"/*.sh 2>/dev/null
echo -e "  ${GREEN}✓${NC} Done"

# --- Reload LaunchAgents ---
echo ""
echo "🔄 Reloading LaunchAgents..."

AGENTS=(
    "com.user.batterymonitor.plist"
    "com.user.systemcheck.plist"
)

for agent in "${AGENTS[@]}"; do
    PLIST="$HOME/Library/LaunchAgents/$agent"
    if [ -f "$PLIST" ]; then
        launchctl unload "$PLIST" 2>/dev/null
        launchctl load "$PLIST"
        echo -e "  ${GREEN}✓${NC} $agent"
    else
        echo -e "  ${YELLOW}⚠️  Not found: $agent${NC}"
    fi
done

# --- Verify ---
echo ""
echo "=============================="
echo "✅ Verification"
echo "=============================="
echo ""
echo "Home directory scripts:"
ls -1 "$HOME"/*.sh 2>/dev/null | while read -r f; do
    echo "  ✓ $(basename "$f")"
done

echo ""
echo ".local/bin scripts:"
ls -1 "$HOME/.local/bin"/*.sh 2>/dev/null | while read -r f; do
    echo "  ✓ $(basename "$f")"
done

echo ""
echo "LaunchAgents:"
launchctl list 2>/dev/null | grep "com.user" | awk '{print "  ✓ " $3}'

echo ""
echo "🎉 All scripts reinstated."
